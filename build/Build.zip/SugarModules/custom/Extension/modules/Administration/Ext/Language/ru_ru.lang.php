<?php
/**
 * Created by PhpStorm.
 * User: alex
 * Date: 14.04.21
 * Time: 23:23
 */
$mod_strings['LBL_WEB_HOOKS_REQUEST']='Запросы веб хуков';
$mod_strings['LBL_WEB_HOOKS_REQUEST_DESCRIPTION']='Отображаются запросы, которые были сформированы модулем процессы для отправки данных на сторонние сервисы';
$mod_strings['LBL_WEB_HOOKS_REQUEST_HEADER']='Запросы веб хуков';
$mod_strings['LBL_WEB_HOOKS_REQUEST_DESCRIPTION_HEADER']='';